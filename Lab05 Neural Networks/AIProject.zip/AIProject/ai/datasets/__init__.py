from .basic import mnist
