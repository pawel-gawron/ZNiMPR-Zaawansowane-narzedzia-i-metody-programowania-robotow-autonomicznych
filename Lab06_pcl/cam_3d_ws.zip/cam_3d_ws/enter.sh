docker exec -it -u $USER znimpra_container bash
