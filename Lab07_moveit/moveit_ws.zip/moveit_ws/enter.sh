docker exec -it -u $USER ros_container bash
